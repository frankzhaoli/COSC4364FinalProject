3-D Cubic Spline

Python 3

Libraries that the code requires: csv, matplotlib, mpl_tookkits, tkinter, PIL, math, time

Input files used: GCorridor.csv, smooth_path.csv

To run: main.py contains the main method, simply run main.py